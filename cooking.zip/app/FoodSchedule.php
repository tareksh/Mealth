<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FoodSchedule extends Model
{
    //
}
